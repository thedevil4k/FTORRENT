FTorrent archive fixture
